#!/bin/sh

# jaudio.sh
# jAudio0.4.5.1
#
# Created by Daniel McEnnis on August 16, 2010
# Copyright 1969 __MyCompanyName__. All rights reserved.

java -Xmx1024M -jar jAudio0_4_5_1.jar
